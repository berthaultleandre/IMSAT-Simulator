/*
 * File: controller_types.h
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.22
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Thu Mar 24 17:59:33 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controller_types_h_
#define RTW_HEADER_controller_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_LsSpeQx2VDYHFH7hEe2oh_
#define DEFINED_TYPEDEF_FOR_struct_LsSpeQx2VDYHFH7hEe2oh_

typedef struct {
  real_T w_chap[3];
  real_T h_chap[3];
  real_T Tc;
  real_T A_data[1701];
  real_T B_data[567];
  real_T K_data[567];
  real_T q_chap_data[180];
  real_T t_reg[21];
} struct_LsSpeQx2VDYHFH7hEe2oh;

#endif

/* Parameters (default storage) */
typedef struct P_controller_T_ P_controller_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_controller_T RT_MODEL_controller_T;

#endif                                 /* RTW_HEADER_controller_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

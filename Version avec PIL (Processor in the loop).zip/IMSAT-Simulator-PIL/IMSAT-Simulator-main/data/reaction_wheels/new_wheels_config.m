function config=new_wheels_config(name,number_of_wheels,distr_matrix)
    config = struct('name', name, 'number_of_wheels',number_of_wheels,'distr_matrix', distr_matrix);
end


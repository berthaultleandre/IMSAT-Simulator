function spacecraft=new_spacecraft(name,dim,weight)
    spacecraft=struct('name',name,'dim',dim,'m',weight);
end
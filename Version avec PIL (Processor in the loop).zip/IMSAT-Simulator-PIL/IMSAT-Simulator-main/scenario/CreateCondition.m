function condition = CreateCondition(name,type,param)
    condition = struct('Name',name,'Type',type,'Parameters',param);
end


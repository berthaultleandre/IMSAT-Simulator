function Rob_chap = point_nadir(state)
    origin=[0;0;0];
    Rob_chap=point(origin,state.pos,state.Rio);
end




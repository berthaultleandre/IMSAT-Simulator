

function y = myMeasurementFcn2(x)
 
y = [x(1); x(2); x(3); x(4); x(5); x(6); x(7)]; 
end
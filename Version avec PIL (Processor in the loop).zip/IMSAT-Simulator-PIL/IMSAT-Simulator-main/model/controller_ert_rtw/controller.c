/*
 * File: controller.c
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.7
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Wed Mar 16 23:01:31 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controller.h"
#include "controller_private.h"

/* Block signals (default storage) */
B_controller_T controller_B;

/* External inputs (root inport signals with default storage) */
ExtU_controller_T controller_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_controller_T controller_Y;

/* Real-time model */
RT_MODEL_controller_T controller_M_;
RT_MODEL_controller_T *const controller_M = &controller_M_;

/* Model step function */
void controller_step(void)
{
  int32_T idx;
  real_T ex;
  int32_T b_k;
  int32_T k;
  real_T rtb_DigitalClock_tmp;
  boolean_T exitg1;

  /* DigitalClock: '<S3>/Digital Clock' incorporates:
   *  DigitalClock: '<S2>/Digital Clock'
   */
  rtb_DigitalClock_tmp = ((controller_M->Timing.clockTick0) * 1.0);

  /* MATLAB Function: '<S3>/K(t)' incorporates:
   *  Constant: '<S3>/t_data'
   *  DigitalClock: '<S3>/Digital Clock'
   */
  for (k = 0; k < 21; k++) {
    controller_B.y[k] = fabs(controller_P.ctrl.t_reg[k] - rtb_DigitalClock_tmp);
  }

  if (!rtIsNaN(controller_B.y[0])) {
    idx = 1;
  } else {
    idx = 0;
    b_k = 2;
    exitg1 = false;
    while ((!exitg1) && (b_k < 22)) {
      if (!rtIsNaN(controller_B.y[b_k - 1])) {
        idx = b_k;
        exitg1 = true;
      } else {
        b_k++;
      }
    }
  }

  if (idx == 0) {
    idx = 1;
  } else {
    ex = controller_B.y[idx - 1];
    for (b_k = idx; b_k + 1 < 22; b_k++) {
      if (ex > controller_B.y[b_k]) {
        ex = controller_B.y[b_k];
        idx = b_k + 1;
      }
    }
  }

  /* MATLAB Function: '<S2>/q_chap(t)' incorporates:
   *  Constant: '<S2>/t_reg'
   */
  for (k = 0; k < 21; k++) {
    controller_B.y[k] = fabs(controller_P.ctrl.t_reg[k] - rtb_DigitalClock_tmp);
  }

  if (!rtIsNaN(controller_B.y[0])) {
    k = 1;
  } else {
    k = 0;
    b_k = 2;
    exitg1 = false;
    while ((!exitg1) && (b_k < 22)) {
      if (!rtIsNaN(controller_B.y[b_k - 1])) {
        k = b_k;
        exitg1 = true;
      } else {
        b_k++;
      }
    }
  }

  if (k == 0) {
    k = 1;
  } else {
    ex = controller_B.y[k - 1];
    for (b_k = k; b_k + 1 < 22; b_k++) {
      if (ex > controller_B.y[b_k]) {
        ex = controller_B.y[b_k];
        k = b_k + 1;
      }
    }
  }

  /* MATLAB Function: '<S3>/K(t)' incorporates:
   *  Product: '<S2>/Product'
   */
  if ((real_T)idx - 1.0 > 1.0) {
    rtb_DigitalClock_tmp = (real_T)idx - 1.0;
  } else {
    rtb_DigitalClock_tmp = 1.0;
  }

  idx = 9 * (int32_T)rtb_DigitalClock_tmp - 9;

  /* MATLAB Function: '<S2>/q_chap(t)' */
  if ((real_T)k - 1.0 > 1.0) {
    rtb_DigitalClock_tmp = (real_T)k - 1.0;
  } else {
    rtb_DigitalClock_tmp = 1.0;
  }

  /* SignalConversion: '<S2>/TmpSignal ConversionAtProductInport2' incorporates:
   *  Constant: '<S2>/g_chap1'
   *  Constant: '<S2>/q_chap_data'
   *  Constant: '<S2>/w_chap'
   *  Inport: '<Root>/h'
   *  Inport: '<Root>/q'
   *  Inport: '<Root>/w'
   *  MATLAB Function: '<S2>/q_chap(t)'
   *  Sum: '<S2>/Subtract'
   *  Sum: '<S2>/Subtract1'
   *  Sum: '<S2>/Subtract2'
   */
  controller_B.dv1[0] = controller_U.w - controller_P.ctrl.w_chap[0];
  controller_B.dv1[3] = controller_U.q[0] - controller_P.ctrl.q_chap_data
    [((int32_T)rtb_DigitalClock_tmp - 1) << 2];
  controller_B.dv1[6] = controller_U.h - controller_P.ctrl.h_chap[0];
  controller_B.dv1[1] = controller_U.w - controller_P.ctrl.w_chap[1];
  controller_B.dv1[4] = controller_U.q[1] - controller_P.ctrl.q_chap_data
    [(((int32_T)rtb_DigitalClock_tmp - 1) << 2) + 1];
  controller_B.dv1[7] = controller_U.h - controller_P.ctrl.h_chap[1];
  controller_B.dv1[2] = controller_U.w - controller_P.ctrl.w_chap[2];
  controller_B.dv1[5] = controller_U.q[2] - controller_P.ctrl.q_chap_data
    [(((int32_T)rtb_DigitalClock_tmp - 1) << 2) + 2];
  controller_B.dv1[8] = controller_U.h - controller_P.ctrl.h_chap[2];

  /* Gain: '<S3>/Gain' incorporates:
   *  Constant: '<S3>/K_data'
   *  MATLAB Function: '<S3>/K(t)'
   *  Product: '<S2>/Product'
   */
  for (k = 0; k < 9; k++) {
    /* Product: '<S2>/Product' incorporates:
     *  Constant: '<S3>/K_data'
     *  MATLAB Function: '<S3>/K(t)'
     */
    b_k = (k + idx) * 3;
    controller_B.dv0[3 * k] = controller_P.ctrl.K_data[b_k] *
      controller_P.Gain_Gain;
    controller_B.dv0[1 + 3 * k] = controller_P.ctrl.K_data[b_k + 1] *
      controller_P.Gain_Gain;
    controller_B.dv0[2 + 3 * k] = controller_P.ctrl.K_data[b_k + 2] *
      controller_P.Gain_Gain;
  }

  /* End of Gain: '<S3>/Gain' */
  for (k = 0; k < 3; k++) {
    /* Outport: '<Root>/T_w_d' incorporates:
     *  Product: '<S2>/Product'
     *  SignalConversion: '<S2>/TmpSignal ConversionAtProductInport2'
     */
    controller_Y.T_w_d[k] = 0.0;
    for (idx = 0; idx < 9; idx++) {
      controller_Y.T_w_d[k] += controller_B.dv0[3 * idx + k] *
        controller_B.dv1[idx];
    }

    /* End of Outport: '<Root>/T_w_d' */

    /* Outport: '<Root>/m_d' */
    controller_Y.m_d[k] = 0.0;
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 1.0, which is the step size
   * of the task. Size of "clockTick0" ensures timer will not overflow during the
   * application lifespan selected.
   */
  controller_M->Timing.clockTick0++;
}

/* Model initialize function */
void controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)controller_M, 0,
                sizeof(RT_MODEL_controller_T));

  /* external inputs */
  (void)memset((void *)&controller_U, 0, sizeof(ExtU_controller_T));

  /* external outputs */
  (void) memset((void *)&controller_Y, 0,
                sizeof(ExtY_controller_T));
}

/* Model terminate function */
void controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

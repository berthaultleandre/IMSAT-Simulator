/*
 * File: controller.h
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.7
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Wed Mar 16 23:01:31 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controller_h_
#define RTW_HEADER_controller_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef controller_COMMON_INCLUDES_
# define controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* controller_COMMON_INCLUDES_ */

#include "controller_types.h"
#include "MW_target_hardware_resources.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T dv0[27];
  real_T y[21];
  real_T dv1[9];
} B_controller_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T B_b;                          /* '<Root>/B_b' */
  real_T w;                            /* '<Root>/w' */
  real_T q[4];                         /* '<Root>/q' */
  real_T R_o_b;                        /* '<Root>/R_o_b' */
  real_T h;                            /* '<Root>/h' */
} ExtU_controller_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T m_d[3];                       /* '<Root>/m_d' */
  real_T T_w_d[3];                     /* '<Root>/T_w_d' */
} ExtY_controller_T;

/* Parameters (default storage) */
struct P_controller_T_ {
  struct_LsSpeQx2VDYHFH7hEe2oh ctrl;   /* Variable: ctrl
                                        * Referenced by:
                                        *   '<S2>/g_chap1'
                                        *   '<S2>/q_chap_data'
                                        *   '<S2>/t_reg'
                                        *   '<S2>/w_chap'
                                        *   '<S3>/K_data'
                                        *   '<S3>/t_data'
                                        */
  real_T Gain_Gain;                    /* Expression: -1
                                        * Referenced by: '<S3>/Gain'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_controller_T {
  const char_T *errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
  } Timing;
};

/* Block parameters (default storage) */
extern P_controller_T controller_P;

/* Block signals (default storage) */
extern B_controller_T controller_B;

/* External inputs (root inport signals with default storage) */
extern ExtU_controller_T controller_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_controller_T controller_Y;

/* Model entry point functions */
extern void controller_initialize(void);
extern void controller_step(void);
extern void controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_controller_T *const controller_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Scope2' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('spacecraft_model_2018aV2/controller')    - opens subsystem spacecraft_model_2018aV2/controller
 * hilite_system('spacecraft_model_2018aV2/controller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'spacecraft_model_2018aV2'
 * '<S1>'   : 'spacecraft_model_2018aV2/controller'
 * '<S2>'   : 'spacecraft_model_2018aV2/controller/LQR'
 * '<S3>'   : 'spacecraft_model_2018aV2/controller/LQR/LQR Variable Gain'
 * '<S4>'   : 'spacecraft_model_2018aV2/controller/LQR/q_chap(t)'
 * '<S5>'   : 'spacecraft_model_2018aV2/controller/LQR/LQR Variable Gain/K(t)'
 */
#endif                                 /* RTW_HEADER_controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

function S = rotate_spacecraft(S, R)
    S=S*R;
end

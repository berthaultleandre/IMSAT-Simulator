function bg = new_buttongroup(fig,pos)
bg = uibuttongroup(fig,'Visible','off','Position',pos);
end


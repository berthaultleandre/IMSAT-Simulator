function cbx = new_checkbox(parent,text)
    cbx = uicontrol(parent,'style','checkbox','String',text);
end


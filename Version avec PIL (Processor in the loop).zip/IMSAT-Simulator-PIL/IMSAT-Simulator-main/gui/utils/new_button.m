function b = new_button(parent,text)
    b = uicontrol(parent,'String',text);
end


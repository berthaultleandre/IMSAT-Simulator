function ed = new_edit(parent,text)
    ed=uicontrol(parent,'style','edit','String',text);
end


function spn = new_spinner(parent,values)
    spn=uicontrol(parent,'style','popup','String',values);
end


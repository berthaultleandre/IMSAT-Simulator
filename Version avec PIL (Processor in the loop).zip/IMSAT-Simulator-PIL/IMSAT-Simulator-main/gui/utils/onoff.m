function state = onoff(bool)
    if (bool==0)
        state='off';
    else
        state='on';
    end
end


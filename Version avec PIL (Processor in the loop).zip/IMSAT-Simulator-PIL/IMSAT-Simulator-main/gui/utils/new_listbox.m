function lstbx = new_listbox(fig,text,pos)
    lstbx = uicontrol(fig,'style','listbox','String',text,'Position',pos);
end


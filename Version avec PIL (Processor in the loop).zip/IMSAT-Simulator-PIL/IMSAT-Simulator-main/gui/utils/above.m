function above(obj1,obj2,marginbottom)
    obj1.Position(1)=obj2.Position(1);
    obj1.Position(2)=obj2.Position(2)+obj2.Position(4)+marginbottom;
end


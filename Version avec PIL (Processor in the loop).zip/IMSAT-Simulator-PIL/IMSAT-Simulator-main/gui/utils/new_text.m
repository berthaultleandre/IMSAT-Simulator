function txt = new_text(parent,text)
    txt=uicontrol(parent,'style','text','String',text);
end


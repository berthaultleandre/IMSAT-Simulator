function Rio = roti2o(v_dir)
    Rio = alignment_rotm([1;0;0],v_dir);
end


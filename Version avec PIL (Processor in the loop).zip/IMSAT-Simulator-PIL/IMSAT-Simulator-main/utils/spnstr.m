function str = spnstr(spn)
    str = spn.String{spn.Value};
end

